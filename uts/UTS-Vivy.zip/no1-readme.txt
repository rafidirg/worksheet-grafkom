Nomor 1 (Animasi Interaktif)

Gambaran Umum:
- Terdapat 3 objek yang pada canvas
- Objek 1 berbentuk pedang, objek 2 berbentuk rumah, dan objek 3 berbentuk bintang

Menjalankan Program:
- Program disimpan dalam folder bernama uts
- Pada direktori uts terdapat folder library yang ada dalam zip file
- Untuk menjalankan program masuk ke folder uts dan buka file no1.html
- Ketika mengakses file html, usahakan perangkat terhubung ke internet
karena styling menggunakan cdn bootstrap

Manual Penggunaan:
- Masing-masing objek dapat digerakkan, dirotasi, diperbesar, dan diperkecil
- Pilih salah satu objek dengan menekan tombol Object 1, Object 2, atau Object 3

Menggerakkan Objek:
- Objek bisa digerakkan dengan menekan key arrow up, right, down, dan left yang 
masing-masing akan bergerak ke atas, kanan, bawah, dan kiri

Rotasi Objek:
- Tekan atau tahan key 'R' pada keyboard agar objek berotasi
- Objek akan berotasi sesuai arah jarum jam

Memperbesar Objek:
- Tekan atau tahan key 'Z' pada keyboard untuk memperbesar objek

Memperkecil Objek:
- Tekan atau tahan key 'X' pada keyboard untuk memperkecil objek

Kontribusi:
Rafi Indrawan Dirgantara:
- Membuat animasi translasi, rotasi, dan skala
- Membuat bentuk bintang

Lazuardi Pratama Putra Nusantara:
- Membuat bentuk pedang dan rumah
- Menambahkan sedikit styling
- Membuat Dokumentasi nomor 1