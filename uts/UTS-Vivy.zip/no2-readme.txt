Nomor 2 (MidPointLine Algorithm)

Gambaran Umum:
- Program akan menampilkan hasil penggambaran garis sesuai dengan titik input pada kode no2.js
- Garis yang dihasilkan bisa di kuadaran 1, 2, 3, maupun 4 tergantung dengan titik input

Menjalankan Program:
- Program disimpan dalam folder bernama uts
- Pada direktori uts terdapat folder library yang ada dalam zip file
- Untuk menjalankan program masuk ke folder uts dan buka file no2.html
- Ketika mengakses file html, usahakan perangkat terhubung ke internet
karena styling menggunakan cdn bootstrap

Manual Penggunaan:
- Menginput titik dapat dengan memanggil method midPointLine(x1, y1, x2, y2) pada awal fungsi render (line 36)
- Untuk penginputan nilai x1 harus lebih kecil dari x2

Kontribusi:
Rafi Indrawan Dirgantara:
- Menginput titik-titik yang diperlukan
- Memplot titik-titik ke canvas

Lazuardi Pratama Putra Nusantara:
- Membuat method midPointLine
- Menambahkan sedikit styling
- Membuat Dokumentasi nomor 2